class Solution {
    public double myPow(double x, int n) {
     return Math.pow(x,n);  
    }
}