bool stoneGame(int* piles, int pilesSize){
return true;
}