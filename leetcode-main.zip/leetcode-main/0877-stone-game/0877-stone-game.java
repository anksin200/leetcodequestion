class Solution {
    public boolean stoneGame(int[] piles) {
        // sum of all the piles is odd so sum of even and sum of odd will never be equal and one of them always high 
        // so alice pick the  highest so every time alice will win the game 
        return true;
    }
}