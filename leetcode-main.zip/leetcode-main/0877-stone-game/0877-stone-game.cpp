class Solution {
public:
    bool stoneGame(vector<int>& piles) {
        return true;
    }
};