class Solution {
    public int strStr(String haystack, String needle) {
        return haystack.indexOf(needle);
    }
}